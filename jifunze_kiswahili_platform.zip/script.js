// Replace this with your own email address before publishing.
const tutorEmail = "YOUR_EMAIL@example.com";

document.getElementById("bookingForm").addEventListener("submit", function(e) {
  e.preventDefault();
  const name = document.getElementById("name").value;
  const email = document.getElementById("email").value;
  const lesson = document.getElementById("lesson").value;
  const date = document.getElementById("date").value;
  const message = document.getElementById("message").value;

  const subject = encodeURIComponent("Kiswahili lesson request - " + name);
  const body = encodeURIComponent(
    `Name: ${name}\nEmail: ${email}\nLesson: ${lesson}\nPreferred date: ${date}\n\nGoals: ${message}`
  );

  if (tutorEmail === "YOUR_EMAIL@example.com") {
    alert("Before publishing, open script.js and replace YOUR_EMAIL@example.com with your email address.");
    return;
  }
  window.location.href = `mailto:${tutorEmail}?subject=${subject}&body=${body}`;
});
