# Jifunze Kiswahili — Starter Platform

This is a simple mobile-friendly Kiswahili tutoring website.

## Before publishing
1. Open `index.html` and replace `[YOUR NAME]`.
2. Open `script.js` and replace `YOUR_EMAIL@example.com` with your email.
3. Replace the lesson prices if you want different prices.

## Important
This starter version does not process payments or automatically schedule video calls.
For payments and bookings, connect a payment/booking service after you have students.

## Files
- index.html — website
- style.css — design
- script.js — booking form
